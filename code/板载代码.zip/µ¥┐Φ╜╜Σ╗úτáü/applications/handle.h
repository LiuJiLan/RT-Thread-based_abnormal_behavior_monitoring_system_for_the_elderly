//
//  handle.h
//  deal_with_serial_data
//
//  Created by ������ on 2021/9/8.
//

#ifndef handle_h
#define handle_h

#include <stdio.h>
typedef int16_t bits_16_int;

void init_static_data(void);
void handle_data(unsigned char);

#endif /* handle_h */

