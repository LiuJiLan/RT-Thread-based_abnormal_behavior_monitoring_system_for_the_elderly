//
//  fall.h
//  fall_decision_ver01
//
//  Created by ������ on 2021/9/15.
//

#ifndef fall_h
#define fall_h

void fall_decisionsignal(float acc);

#endif /* fall_h */
